﻿using System;

namespace Midterm
{
    class Program
    {
        static void Main(string[] args)
        {
            bool keepgoing = true;
            do
            {
                Console.WriteLine("Please enter your street address");
                String address = Console.ReadLine();

                while (string.IsNullOrEmpty(address))
                {
                    Console.WriteLine("Please enter your street address");
                    address = Console.ReadLine();
                }
                    Console.WriteLine("Please enter your province");
                    string province = Console.ReadLine();

                    while (string.IsNullOrEmpty(province))
                    {
                        Console.WriteLine("Please enter your province");
                        province = Console.ReadLine();
                    }

                    if (address == "END" || address == "end" || province == "END" || province == "end")
                    {
                        keepgoing = false;
                    }
                    else
                    {
                        Console.WriteLine("Input Number 1:");
                        decimal number1 = Convert.ToDecimal(Console.ReadLine());
                        Console.WriteLine("Input Number 2:");
                        decimal number2 = Convert.ToDecimal(Console.ReadLine());

                        Console.WriteLine("Please Select One of the Operation you would like to operate:");
                        Console.WriteLine("Option 1: Add both numbers");
                        Console.WriteLine("Option 2: Multiply both numbers");
                        Console.WriteLine("Option 3: Divide the second number by the first one");
                        Console.WriteLine("Option 4: Substract the first number from the second");
                        Console.WriteLine("Please input the desired option number:");
                        string options = Console.ReadLine();

                        while (string.IsNullOrEmpty(options))
                        {
                            Console.WriteLine("Please Select One of the Operation you would like to operate:");
                            Console.WriteLine("Option 1: Add both numbers");
                            Console.WriteLine("Option 2: Multiply both numbers");
                            Console.WriteLine("Option 3: Divide the second number by the first one");
                            Console.WriteLine("Option 4: Substract the first number from the second");
                            Console.WriteLine("Please input the desired option number:");
                            options = (Console.ReadLine());
                        }
                        decimal option = Convert.ToDecimal(options);
                        decimal answer = 0;

                        if (option == 1)
                        {
                            answer = number1 + number2;
                        }
                        else if (option == 2)
                        {
                            answer = number1 * number2;

                        }
                        else if (option == 3)
                        {
                            answer = number2 * number1;
                        }
                        else if (option == 4)
                        {
                            answer = number1 - number2;
                        }
                        else
                        {
                        }


                        switch (answer)
                        {
                            case 300:
                                {
                                    Console.WriteLine("The two numbers must calculate to less than 300.");
                                }
                                break;
                            case 50:
                                {
                                    answer = answer * 7 + 2;
                                }
                                break;
                            case 30:
                                {
                                }
                                break;
                            default:
                                answer = answer + 0;
                                break;
                        }

                        Console.WriteLine("You live at " + address + " " + province + "and your answer is " + answer);
                        Console.WriteLine("Please enter END in the address or province to exit");
                    }
                
            } while (keepgoing);
        }
    }
}
