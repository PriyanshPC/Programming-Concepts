﻿//Priyansh Chaudhary        8650731//

using System;

namespace PriyanshChaudhary
{
    class Program
    {

        static void Main(string[] args)
        {
         
            // ask for first and last name and store them to a variable//
            Console.WriteLine("Please Enter First Name");
            string FirstName = Console.ReadLine();
            Console.WriteLine("Please Enter Last Name");
            string LastName = Console.ReadLine();
            String str;

            // bool tag for the loop function//
             bool Exit = true;

            do
            {
                //try and catch for the string error//
                try
                {
                    Console.WriteLine("Please Enter a String");
                    str = Console.ReadLine();
                }
                catch (Exception)
                {
                    Console.WriteLine("Error Nothing Entered");
                    Console.WriteLine("Please Enter a String");
                    str = Console.ReadLine();
                }

                if (str == "Quit" || str == "QUIT" || str == "quit")
                {
                    Console.BackgroundColor = ConsoleColor.Yellow;
                    Console.ForegroundColor = ConsoleColor.Black;
                    Console.Write("-------Thanks for your time. Have a great day.--------");
                    Console.ResetColor();
                    Console.WriteLine();
                    Exit = false;
                }
                //main program//
                else
                {
                    int i;
                    string str2 = "";
                    if (str.Length > 19)
                    {
                        //to eleminate all the vowels//
                        for (i = 0; i < str.Length; i++)
                        {
                            if (str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' || str[i] == 'A' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U')
                            {

                            }
                            else
                            {
                                str2 = str2 + str[i];
                            }
                        }

                    }
                    else
                    {
                        // if the string is incorrect//
                        str2 = "Incorrect String " + str;
                    }

                    //Display Result//
                    Console.WriteLine(FirstName + " " + LastName + " " + str2);
                }
                

            } while (Exit);
            
        }
    }
}
