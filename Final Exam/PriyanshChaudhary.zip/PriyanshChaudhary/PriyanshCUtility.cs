﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriyanshChaudhary
{
    class PriyanshCUtility
    {
        
        //Variables
        private string FirstName;
        private string LastName;
    
        //default constructor
        public PriyanshCUtility()
        {
            FirstName = "";
            LastName = "";
        }

        //non-default constructor
        public PriyanshCUtility(String FirstName, String LastName)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
        }
        
        // static method to eleminate all the vowels from the string//
        static string AutoSentenceUpdate(String FirstName, String LastName, string str)
        {
            int i;
            string str2="";
            if (str.Length>19)
            {
              for(i=0;i<str.Length; i++)
                {
                    if(str[i]=='a'|| str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u' || str[i] == 'A' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U')
                    {

                    }
                    else
                    {
                        str2 = FirstName + LastName + str2 + str[i];
                    }
                }

            }
            else
            {
                str2 = FirstName + LastName + "Incorrect String" + str;
            }

            return str2;
        }

    }
}
