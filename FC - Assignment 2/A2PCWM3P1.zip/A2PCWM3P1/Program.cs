﻿using System;

namespace A2PCWM3P1
{
    class Program
    {
        //Priyansh Chaudhary
        //Wisam Moussa
        static void Main(string[] args)
        {
            //Step 1//
            Console.WriteLine("In which quarter customer registered : [1st Quater Press 1] [2nd Quater Press 2] [3rd Quater Press 3] [4th Quater Press 4] ");
            string quarter = (Console.ReadLine());
            Console.WriteLine("Customer Membership number : ");
            string membership = (Console.ReadLine());
            Console.WriteLine("Number of Items Purchased : ");
            int items = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Cost of an item : $");
            decimal itemcost = Convert.ToDecimal(Console.ReadLine());
            decimal subtotal = Convert.ToDecimal(items) * itemcost;
            decimal totalcost;

            //Step2//
            if (items > 5 & items < 10)
            {
                totalcost = subtotal - 20;
            }
            else if (items >= 10)
            {
                totalcost = subtotal * 70 / 100;
            }
            else
            {
                totalcost = subtotal;
            }
            if (totalcost < 0)
            {
                totalcost = subtotal * 13 / 100;
            }

            //Step3//
            if (totalcost > 100)
            {
                totalcost = totalcost * 975 / 1000;
            }
            else if (totalcost < 30)
            {
                totalcost = totalcost - 2;
            }
            if (totalcost < 0)
            {
                totalcost = 0;
            }

            //Step4//
            switch (quarter)
            {
                case "1":
                case "2":
                    totalcost = totalcost - 15;
                    break;
                case "3":
                    totalcost = totalcost - 5;
                    break;
                default:
                    totalcost = totalcost - 1;
                    break;
            }
            if (totalcost < 0)
            {
                totalcost = 0;
            }

            //Step5//
            totalcost = totalcost * 113 / 100;

            //Step6//
            Console.WriteLine("Membership Number : " + membership);
            Console.WriteLine("Number of Items : " + items);
            Console.WriteLine("Total cost before discount : " + subtotal);
            if (totalcost < 20)
            {
                Console.WriteLine("Final cost (inc tax) : !! FREE !!");
            }
            else
            {
                Console.WriteLine("Final cost (inc tax) : " + totalcost);
            }
        }
    }
}