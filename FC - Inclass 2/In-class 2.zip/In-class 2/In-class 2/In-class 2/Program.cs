﻿using System;

namespace In_class_2
{
    class Program
    {
        static void Main(string[] args)
        {
            //1
            string pcStr1;
            string wmStr2;
            string pcStr3;
            string wmStr4;
            string pcStr5;
           
            //2
            Console.WriteLine("Enter three numbers of 4 digits each");
            pcStr1 = Console.ReadLine();
            wmStr2 = Console.ReadLine();
            pcStr3 = Console.ReadLine();

            //3
            double cal4;
            double cal5;
            double wmDou1;
            double pcDou2;
            double wmDou3;
            double pcDou4;
            double wmDou5;
            wmDou1 = double.Parse(pcStr1);
            pcDou2 = double.Parse(wmStr2);
            wmDou3 = double.Parse(pcStr3);

            //4
            cal4 = (wmDou1 + pcDou2);
            wmStr4 = cal4.ToString("N");

            //5
            cal5 = (wmDou3 * 22);
            pcStr5 = cal5.ToString("N");

            //6
            double addition;
            addition = (wmDou1 + pcDou2 + wmDou3);
            int pcTotalSum = Convert.ToInt32(addition);

            //7
            pcDou4 = double.Parse(wmStr4);
            wmDou5 = double.Parse(pcStr5);
            int wmlasttwo = Convert.ToInt32(pcDou4*wmDou5);

            //8
            double addition2 = Convert.ToDouble(pcTotalSum+wmlasttwo);

            //9
            double sub = (Convert.ToDouble(wmlasttwo)) - (double.Parse(wmStr4));

            //10
            Console.WriteLine("Line 4 (wmStr4) = " + wmStr4);
            Console.WriteLine("Line 5 (pcStr5) = " + pcStr5);
            Console.WriteLine("Line 6 (pcTotalSum) = " + pcTotalSum);
            Console.WriteLine("line 7 (wmlasttwo) = " + wmlasttwo);
            Console.WriteLine("Line 8 (addition2) = " + addition2);
            Console.WriteLine("Line 9 (subract) = " + sub);

            //the program wont run and will show an error because there will be no number to save in string or double
            //yes every calculation went according to the plan
            //so if anyone put 9999 in all three no.s then the program wont be able to calculate as the value will be to large for the integers.
        }
    }
}
