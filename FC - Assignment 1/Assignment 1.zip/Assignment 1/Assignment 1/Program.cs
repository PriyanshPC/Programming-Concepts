﻿using System;

namespace Assignment_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string CelsiusT;
            double Calculation;

            Console.WriteLine("A Student - Assignment 1 Part 2");
            Console.WriteLine("Name : Priyansh Chaudhary & Wisam Moussa");
            Console.WriteLine("Email : Pchaudhary0731@conestogac.on.ca  & Wmoussa0957@conestogac.on.ca");
            // get the temperature
            Console.WriteLine("Enter the Temperature in Celsius");
            CelsiusT = Console.ReadLine();
            // converting string input to double
            double ConCelT = double.Parse(CelsiusT);
            // performing calculation
            Calculation = (ConCelT * 9 / 5) + 32;
            // output result to the screen
            Console.WriteLine("Fahrenheit = " + Calculation);
            Console.WriteLine("Experience : No experience at all. Doing it for the first time");
            Console.WriteLine("Country : Canada");
        }
    }
}
